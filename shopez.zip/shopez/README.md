# 🛍️ ShopEZ
Full-stack e-commerce app: Node.js + Express backend (JWT auth, JSON-file storage) and a vanilla JS frontend.

## Features
Product catalog with search & categories · discounts · reviews & ratings · cart · checkout with instant order confirmation and stock control · buyer/seller accounts · seller dashboard (revenue, top products, low stock, add products, update order status).

## Run
```bash
npm install
npm start        # http://localhost:3000
```
Demo seller: `seller@shopez.com` / `seller123`. Set `JWT_SECRET` and `PORT` via environment variables in production.

## API
`POST /api/register|login` · `GET /api/products?q=&category=` · `POST /api/products` (seller) · `POST /api/products/:id/reviews` · `POST /api/orders` · `GET /api/orders` · `PATCH /api/orders/:id` (seller) · `GET /api/seller/analytics` (seller)

## Next steps
Swap `data.json` for MongoDB/PostgreSQL, add a real payment gateway (Razorpay/Stripe), image uploads.
