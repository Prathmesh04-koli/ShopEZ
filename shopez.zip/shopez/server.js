const express=require('express'),fs=require('fs'),path=require('path'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const app=express(),SECRET=process.env.JWT_SECRET||'change-me',DB=path.join(__dirname,'data.json');
app.use(express.json());app.use(express.static(path.join(__dirname,'public')));
const load=()=>JSON.parse(fs.readFileSync(DB)),save=d=>fs.writeFileSync(DB,JSON.stringify(d,null,2));
const P=(id,title,category,price,discount,stock,emoji,description)=>({id,sellerId:1,title,category,price,discount,stock,emoji,description,reviews:[]});
if(!fs.existsSync(DB))save({users:[{id:1,name:'Demo Seller',email:'seller@shopez.com',role:'seller',hash:bcrypt.hashSync('seller123',8)}],orders:[],products:[
P(1,'Wireless Headphones','Electronics',2999,20,25,'🎧','Noise-isolating over-ear headphones with 30h battery.'),
P(2,'Smart Watch','Electronics',4999,15,18,'⌚','Fitness tracking, heart-rate monitor, AMOLED display.'),
P(3,'Running Shoes','Fashion',2499,10,40,'👟','Lightweight breathable shoes built for daily runs.'),
P(4,'Denim Jacket','Fashion',1899,0,30,'🧥','Classic fit denim jacket, all-season wear.'),
P(5,'Coffee Maker','Home',3499,25,12,'☕','Programmable 12-cup drip coffee maker.'),
P(6,'Desk Lamp','Home',899,5,50,'💡','Dimmable LED lamp with USB charging port.'),
P(7,'Backpack','Fashion',1299,0,35,'🎒','Water-resistant 25L backpack with laptop sleeve.'),
P(8,'Bluetooth Speaker','Electronics',1999,30,22,'🔊','Portable speaker, 12h playtime, IPX7 waterproof.')]});
const final=p=>Math.round(p.price*(100-p.discount)/100);
const auth=(role)=>(req,res,next)=>{try{req.user=jwt.verify((req.headers.authorization||'').replace('Bearer ',''),SECRET)}catch{return res.status(401).json({error:'Please log in'})}
 if(role&&req.user.role!==role)return res.status(403).json({error:'Not allowed'});next()};
const token=u=>({token:jwt.sign({id:u.id,name:u.name,role:u.role},SECRET,{expiresIn:'7d'}),user:{id:u.id,name:u.name,role:u.role}});
app.post('/api/register',(req,res)=>{const{name,email,password,role}=req.body,d=load();
 if(!name||!email||!password||password.length<6)return res.status(400).json({error:'Name, email and 6+ char password required'});
 if(d.users.some(u=>u.email===email.toLowerCase()))return res.status(400).json({error:'Email already registered'});
 const u={id:Date.now(),name,email:email.toLowerCase(),role:role==='seller'?'seller':'buyer',hash:bcrypt.hashSync(password,8)};d.users.push(u);save(d);res.json(token(u))});
app.post('/api/login',(req,res)=>{const u=load().users.find(u=>u.email===(req.body.email||'').toLowerCase());
 if(!u||!bcrypt.compareSync(req.body.password||'',u.hash))return res.status(401).json({error:'Invalid credentials'});res.json(token(u))});
app.get('/api/products',(req,res)=>{const{q='',category=''}=req.query;
 res.json(load().products.filter(p=>(!category||p.category===category)&&(p.title+p.description).toLowerCase().includes(q.toLowerCase())).map(p=>({...p,finalPrice:final(p)})))});
app.get('/api/products/:id',(req,res)=>{const p=load().products.find(p=>p.id==req.params.id);p?res.json({...p,finalPrice:final(p)}):res.status(404).json({error:'Not found'})});
app.post('/api/products',auth('seller'),(req,res)=>{const b=req.body,d=load();
 if(!b.title||!(b.price>0))return res.status(400).json({error:'Title and price required'});
 const p={id:Date.now(),sellerId:req.user.id,title:b.title,category:b.category||'Other',price:+b.price,discount:Math.min(90,+b.discount||0),stock:+b.stock||0,emoji:b.emoji||'📦',description:b.description||'',reviews:[]};
 d.products.push(p);save(d);res.json(p)});
app.post('/api/products/:id/reviews',auth(),(req,res)=>{const d=load(),p=d.products.find(p=>p.id==req.params.id),r=+req.body.rating;
 if(!p||!(r>=1&&r<=5))return res.status(400).json({error:'Rating 1-5 required'});
 p.reviews.push({user:req.user.name,rating:r,comment:String(req.body.comment||'').slice(0,300),date:new Date().toISOString()});save(d);res.json(p)});
app.post('/api/orders',auth(),(req,res)=>{const d=load(),{items,address}=req.body;
 if(!Array.isArray(items)||!items.length||!address)return res.status(400).json({error:'Items and address required'});
 const lines=[];for(const i of items){const p=d.products.find(p=>p.id==i.id),q=+i.qty;
  if(!p||!(q>0))return res.status(400).json({error:'Invalid item'});if(p.stock<q)return res.status(400).json({error:`Only ${p.stock} left of ${p.title}`});
  lines.push({p,q})}
 lines.forEach(({p,q})=>p.stock-=q);
 const o={id:'ORD-'+Date.now().toString(36).toUpperCase(),userId:req.user.id,buyer:req.user.name,address,date:new Date().toISOString(),status:'Confirmed',
  items:lines.map(({p,q})=>({id:p.id,sellerId:p.sellerId,title:p.title,price:final(p),qty:q})),total:lines.reduce((s,{p,q})=>s+final(p)*q,0)};
 d.orders.push(o);save(d);res.json(o)});
app.get('/api/orders',auth(),(req,res)=>{const o=load().orders;
 res.json(req.user.role==='seller'?o.filter(x=>x.items.some(i=>i.sellerId===req.user.id)):o.filter(x=>x.userId===req.user.id))});
app.patch('/api/orders/:id',auth('seller'),(req,res)=>{const d=load(),o=d.orders.find(o=>o.id===req.params.id);
 if(!o)return res.status(404).json({error:'Not found'});o.status=req.body.status;save(d);res.json(o)});
app.get('/api/seller/analytics',auth('seller'),(req,res)=>{const d=load(),mine=d.products.filter(p=>p.sellerId===req.user.id),by={};let revenue=0,units=0,orders=0;
 d.orders.forEach(o=>{const l=o.items.filter(i=>i.sellerId===req.user.id);if(!l.length)return;orders++;
  l.forEach(i=>{revenue+=i.price*i.qty;units+=i.qty;by[i.title]=(by[i.title]||0)+i.qty})});
 res.json({revenue,units,orders,products:mine.length,lowStock:mine.filter(p=>p.stock<10).map(p=>({title:p.title,stock:p.stock})),
  topProducts:Object.entries(by).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([title,units])=>({title,units})),mine})});
app.listen(process.env.PORT||3000,()=>console.log('ShopEZ running on http://localhost:'+(process.env.PORT||3000)));
